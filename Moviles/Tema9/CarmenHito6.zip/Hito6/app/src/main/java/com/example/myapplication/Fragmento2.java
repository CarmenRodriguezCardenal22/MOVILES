package com.example.myapplication;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.ListFragment;

public class Fragmento2 extends FragmentActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_unpanel);

        if (savedInstanceState == null) {
            // Recuperar el argumento desde el Intent
            String itemId = getIntent().getStringExtra(Fragmento3.ARG_ID_ENTRADA_SELECCIONADA);

            // Crear y configurar el Fragmento3 con los argumentos
            Bundle arguments = new Bundle();
            arguments.putString(Fragmento3.ARG_ID_ENTRADA_SELECCIONADA, itemId);

            Fragmento3 fragment = new Fragmento3();
            fragment.setArguments(arguments);

            getSupportFragmentManager().beginTransaction()
                    .add(R.id.frame_contenedor, fragment)
                    .commit();
        }
    }
}
